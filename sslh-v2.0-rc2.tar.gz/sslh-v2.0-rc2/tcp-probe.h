#ifndef TCP_PROBE_H
#define TCP_PROBE_H

void tcp_init(void);

#endif
